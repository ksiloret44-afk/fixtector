"use strict";(()=>{var e={};e.id=7551,e.ids=[7551],e.modules={72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},27790:e=>{e.exports=require("assert")},61212:e=>{e.exports=require("async_hooks")},78893:e=>{e.exports=require("buffer")},61282:e=>{e.exports=require("child_process")},84770:e=>{e.exports=require("crypto")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},20629:e=>{e.exports=require("fs/promises")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},86624:e=>{e.exports=require("querystring")},74175:e=>{e.exports=require("tty")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},89690:(e,r,t)=>{t.r(r),t.d(r,{originalPathname:()=>g,patchFetch:()=>f,requestAsyncStorage:()=>d,routeModule:()=>u,serverHooks:()=>x,staticGenerationAsyncStorage:()=>m});var s={};t.r(s),t.d(s,{POST:()=>l});var o=t(49303),i=t(88716),n=t(60670),a=t(87070),p=t(75571),c=t(90455);async function l(e){try{if(!await (0,p.getServerSession)(c.L))return a.NextResponse.json({error:"Non autoris\xe9"},{status:401});let r=await e.json();if(!r.domain||!r.serverType)return a.NextResponse.json({error:"Configuration incompl\xe8te"},{status:400});if(!r.useReverseProxy&&!r.documentRoot)return a.NextResponse.json({error:"Document Root requis si reverse proxy n'est pas activ\xe9"},{status:400});let t="";return t="apache"===r.serverType?function(e){let r=e.serverAlias&&e.serverAlias.length>0?`
    ServerAlias ${e.serverAlias.join(" ")}`:"",t="win32"===process.platform,s=t?"logs":"${APACHE_LOG_DIR}",o=e.documentRoot||(t?"C:/Apache24/htdocs/fixtector":"/var/www/html"),i=e.proxyTarget||"http://localhost:3001",n=`<VirtualHost *:${e.port}>
    ServerName ${e.domain}${r}
    
    # Logs
    ErrorLog "${s}/${e.domain}_error.log"
    CustomLog "${s}/${e.domain}_access.log" combined
`;if(e.useReverseProxy?n+=`
    # Reverse Proxy vers Node.js Next.js
    ProxyPreserveHost On
    ProxyRequests Off
    
    # Redirection vers Node.js
    ProxyPass / ${i}/
    ProxyPassReverse / ${i}/
    
    # WebSocket support (pour HMR et WebSockets)
    RewriteEngine On
    RewriteCond %{HTTP:Upgrade} =websocket [NC]
    RewriteRule /(.*) ws://localhost:${i.match(/:(\d+)/)?.[1]||"3001"}/$1 [P,L]
    
    # Headers de s\xe9curit\xe9
    Header always set X-Content-Type-Options "nosniff"
    Header always set X-Frame-Options "DENY"
    Header always set X-XSS-Protection "1; mode=block"
    Header always set Referrer-Policy "strict-origin-when-cross-origin"
    
    # Compression
    <Location />
        SetOutputFilter DEFLATE
        SetEnvIfNoCase Request_URI \
            \\.(?:gif|jpe?g|png|ico|zip|gz|bz2|pdf|mp3|mp4|mov|avi|wmv|flv|swf)$ no-gzip dont-vary
    </Location>
`:n+=`
    DocumentRoot "${o}"
    
    <Directory "${o}">
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
`,e.sslEnabled&&443===e.port){let r=e.sslCertPath||(t?`C:/Apache24/conf/ssl/${e.domain}/fullchain.pem`:`/etc/letsencrypt/live/${e.domain}/fullchain.pem`),s=e.sslKeyPath||(t?`C:/Apache24/conf/ssl/${e.domain}/privkey.pem`:`/etc/letsencrypt/live/${e.domain}/privkey.pem`);n+=`
    # SSL Configuration
    SSLEngine on
    SSLCertificateFile "${r}"
    SSLCertificateKeyFile "${s}"
    
    # SSL Protocol (s\xe9curis\xe9)
    SSLProtocol all -SSLv2 -SSLv3 -TLSv1 -TLSv1.1
    SSLCipherSuite HIGH:!aNULL:!MD5:!3DES
    SSLHonorCipherOrder on
    
    # HSTS (HTTP Strict Transport Security)
    Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains; preload"
`,e.useReverseProxy&&(n+=`
    # Headers de s\xe9curit\xe9 suppl\xe9mentaires pour HTTPS
    Header always set Content-Security-Policy "default-src 'self'"
`),e.redirectHttp&&(n+=`
    # Redirection HTTP vers HTTPS
    RewriteEngine on
    RewriteCond %{HTTPS} off
    RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [R=301,L]
`)}return!e.useReverseProxy&&e.phpVersion&&(n+=`
    # PHP Configuration
    <FilesMatch \\.php$>
        SetHandler "proxy:unix:/var/run/php/php${e.phpVersion}-fpm.sock|fcgi://localhost"
    </FilesMatch>
`),e.customConfig&&(n+=`
    # Configuration personnalis\xe9e
${e.customConfig}
`),n+=`</VirtualHost>
`,e.sslEnabled&&e.redirectHttp&&(n=`<VirtualHost *:80>
    ServerName ${e.domain}${r}
    Redirect permanent / https://${e.domain}/
</VirtualHost>

${n}`),n}(r):function(e){let r=e.serverAlias&&e.serverAlias.length>0?e.serverAlias.map(e=>`    ${e};`).join("\n"):"",t=`server {
    listen ${e.port}${e.sslEnabled?" ssl http2":""};
    server_name ${e.domain}${r?"\n"+r:""};
    
    root ${e.documentRoot};
    index index.php index.html index.htm;
    
    # Logs
    access_log /var/log/nginx/${e.domain}_access.log;
    error_log /var/log/nginx/${e.domain}_error.log;
`;return e.sslEnabled&&443===e.port&&(t+=`
    # SSL Configuration
    ssl_certificate ${e.sslCertPath||"/etc/ssl/certs/ssl-cert-snakeoil.pem"};
    ssl_certificate_key ${e.sslKeyPath||"/etc/ssl/private/ssl-cert-snakeoil.key"};
    
    # SSL Security
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;
    
    # HSTS
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
`,e.redirectHttp&&(t=`server {
    listen 80;
    server_name ${e.domain}${r?"\n"+r:""};
    return 301 https://$server_name$request_uri;
}

${t}`)),t+=`
    # PHP-FPM Configuration
    location ~ \\.php$ {
        fastcgi_pass unix:/var/run/php/php${e.phpVersion||"8.1"}-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }
    
    # S\xe9curit\xe9
    location ~ /\\. {
        deny all;
        access_log off;
        log_not_found off;
    }
    
    # Assets statiques
    location ~* \\.(jpg|jpeg|png|gif|ico|css|js|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        access_log off;
    }
`,e.customConfig&&(t+=`
    # Configuration personnalis\xe9e
${e.customConfig}
`),t+=`}
`}(r),a.NextResponse.json({config:t})}catch(e){return console.error("Erreur:",e),a.NextResponse.json({error:"Une erreur est survenue"},{status:500})}}let u=new o.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/vhost/generate/route",pathname:"/api/vhost/generate",filename:"route",bundlePath:"app/api/vhost/generate/route"},resolvedPagePath:"C:\\Users\\dj-ke.DESKTOP-1UI8AT5\\Documents\\weqeep-test\\app\\api\\vhost\\generate\\route.ts",nextConfigOutput:"",userland:s}),{requestAsyncStorage:d,staticGenerationAsyncStorage:m,serverHooks:x}=u,g="/api/vhost/generate/route";function f(){return(0,n.patchFetch)({serverHooks:x,staticGenerationAsyncStorage:m})}}};var r=require("../../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),s=r.X(0,[4736,8592],()=>t(89690));module.exports=s})();