"use strict";(()=>{var e={};e.id=9118,e.ids=[9118],e.modules={72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},27790:e=>{e.exports=require("assert")},61212:e=>{e.exports=require("async_hooks")},78893:e=>{e.exports=require("buffer")},61282:e=>{e.exports=require("child_process")},84770:e=>{e.exports=require("crypto")},80665:e=>{e.exports=require("dns")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},20629:e=>{e.exports=require("fs/promises")},32615:e=>{e.exports=require("http")},32694:e=>{e.exports=require("http2")},35240:e=>{e.exports=require("https")},98216:e=>{e.exports=require("net")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},86624:e=>{e.exports=require("querystring")},76162:e=>{e.exports=require("stream")},82452:e=>{e.exports=require("tls")},74175:e=>{e.exports=require("tty")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},53780:(e,r,o)=>{o.r(r),o.d(r,{originalPathname:()=>g,patchFetch:()=>P,requestAsyncStorage:()=>S,routeModule:()=>x,serverHooks:()=>O,staticGenerationAsyncStorage:()=>v});var s={};o.r(s),o.d(s,{POST:()=>m});var t=o(49303),i=o(88716),a=o(60670),n=o(87070),p=o(90940),l=o(76876),u=o(84770),d=o(55245),c=o(80620);async function m(e){try{let r,o,s,t;let{email:i}=await e.json();if(!i||!i.includes("@"))return n.NextResponse.json({error:"Adresse email valide requise"},{status:400});let a=(0,p.getMainPrisma)(),m=await a.user.findUnique({where:{email:i}});if(!m)return await new Promise(e=>setTimeout(e,500)),n.NextResponse.json({message:"Si un compte existe avec cette adresse email, vous recevrez un lien de r\xe9initialisation."});if(!m.approved||m.suspended)return n.NextResponse.json({message:"Si un compte existe avec cette adresse email, vous recevrez un lien de r\xe9initialisation."});let x=(0,u.randomBytes)(32).toString("hex"),S=new Date;S.setHours(S.getHours()+1),await a.passwordResetToken.deleteMany({where:{userId:m.id,OR:[{used:!0},{expiresAt:{lt:new Date}}]}}),await a.passwordResetToken.create({data:{userId:m.id,token:x,expiresAt:S}});let v=587,O=!1,g="env";try{let e=m.companyId||null;if(!e){let r=await a.company.findFirst({select:{id:!0}});e=r?.id||null}if(e){let i=(0,p.AA)(e),a=await (0,l.Q2)(i);a.emailEnabled&&a.smtpHost&&a.smtpUser&&a.smtpPassword&&(r=a.smtpHost,v=a.smtpPort||587,o=a.smtpUser,s=a.smtpPassword,t=a.smtpFrom||a.smtpUser,O=a.emailEnabled,g="db",console.log("[FORGOT-PASSWORD] ✓ Configuration SMTP r\xe9cup\xe9r\xe9e depuis les param\xe8tres de l'application"))}}catch(e){console.warn("[FORGOT-PASSWORD] Impossible de r\xe9cup\xe9rer la config depuis la DB:",e)}(!r||!o||!s)&&(r=process.env.SMTP_HOST,v=process.env.SMTP_PORT?parseInt(process.env.SMTP_PORT):587,o=process.env.SMTP_USER,s=process.env.SMTP_PASSWORD,t=process.env.SMTP_FROM||o,g="env",(r||o||s)&&console.log("[FORGOT-PASSWORD] Utilisation de la configuration SMTP depuis les variables d'environnement"));let P=await (0,c.S)(),T=`${P}/reset-password/${x}`,R=!!(r&&o&&s);console.log("[FORGOT-PASSWORD] Configuration SMTP:",{source:g,smtpHost:r?"✓ Configur\xe9":"✗ Manquant",smtpUser:o?"✓ Configur\xe9":"✗ Manquant",smtpPassword:s?"✓ Configur\xe9":"✗ Manquant",smtpPort:v,smtpFrom:t||"Non d\xe9fini",emailEnabled:O,configured:R});let f=!1;try{if(R&&O){let e=d.createTransport({host:r,port:v,secure:465===v,auth:{user:o,pass:s}}),i=`
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="utf-8">
            <style>
              body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
              .container { max-width: 600px; margin: 0 auto; padding: 20px; }
              .button { display: inline-block; padding: 12px 24px; background-color: #4F46E5; color: white; text-decoration: none; border-radius: 6px; margin: 20px 0; }
              .button:hover { background-color: #4338CA; }
              .footer { margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; font-size: 12px; color: #666; }
            </style>
          </head>
          <body>
            <div class="container">
              <h2>R\xe9initialisation de votre mot de passe</h2>
              <p>Bonjour ${m.name},</p>
              <p>Vous avez demand\xe9 \xe0 r\xe9initialiser votre mot de passe pour votre compte FixTector.</p>
              <p>Cliquez sur le bouton ci-dessous pour cr\xe9er un nouveau mot de passe :</p>
              <a href="${T}" class="button">R\xe9initialiser mon mot de passe</a>
              <p>Ou copiez et collez ce lien dans votre navigateur :</p>
              <p style="word-break: break-all; color: #4F46E5;">${T}</p>
              <p><strong>Ce lien expire dans 1 heure.</strong></p>
              <p>Si vous n'avez pas demand\xe9 cette r\xe9initialisation, ignorez simplement cet email.</p>
              <div class="footer">
                <p>Cet email a \xe9t\xe9 envoy\xe9 automatiquement, merci de ne pas y r\xe9pondre.</p>
              </div>
            </div>
          </body>
          </html>
        `,a=`
R\xe9initialisation de votre mot de passe

Bonjour ${m.name},

Vous avez demand\xe9 \xe0 r\xe9initialiser votre mot de passe pour votre compte FixTector.

Cliquez sur le lien suivant pour cr\xe9er un nouveau mot de passe :
${T}

Ce lien expire dans 1 heure.

Si vous n'avez pas demand\xe9 cette r\xe9initialisation, ignorez simplement cet email.

Cet email a \xe9t\xe9 envoy\xe9 automatiquement, merci de ne pas y r\xe9pondre.
        `,n=await e.sendMail({from:t,to:m.email,subject:"R\xe9initialisation de votre mot de passe - FixTector",text:a,html:i});f=!0,console.log(`[FORGOT-PASSWORD] ✓ Email de r\xe9initialisation envoy\xe9 \xe0 ${m.email}`),console.log(`[FORGOT-PASSWORD] Message ID: ${n.messageId}`)}else console.error("[FORGOT-PASSWORD] ✗ Email non configur\xe9 - impossible d'envoyer l'email de r\xe9initialisation"),"db"===g?(console.error("[FORGOT-PASSWORD] Configuration trouv\xe9e dans les param\xe8tres mais:"),console.error("  - emailEnabled:",O?"✓ Activ\xe9":"✗ D\xc9SACTIV\xc9"),console.error("  - SMTP_HOST:",r?"✓":"✗ MANQUANT"),console.error("  - SMTP_USER:",o?"✓":"✗ MANQUANT"),console.error("  - SMTP_PASSWORD:",s?"✓":"✗ MANQUANT"),console.error("[FORGOT-PASSWORD] Activez et configurez l'email dans Param\xe8tres > Notifications")):(console.error("[FORGOT-PASSWORD] Variables SMTP manquantes dans .env.local:"),console.error("  - SMTP_HOST:",r?"✓":"✗ MANQUANT"),console.error("  - SMTP_USER:",o?"✓":"✗ MANQUANT"),console.error("  - SMTP_PASSWORD:",s?"✓":"✗ MANQUANT"),console.error("[FORGOT-PASSWORD] Ou configurez l'email dans Param\xe8tres > Notifications de l'application"))}catch(e){f=!1,console.error("[FORGOT-PASSWORD] ✗ Erreur lors de l'envoi de l'email:",e),console.error("[FORGOT-PASSWORD] D\xe9tails de l'erreur:",{message:e?.message,code:e?.code,command:e?.command,response:e?.response,responseCode:e?.responseCode,stack:e?.stack})}return f?console.log(`[FORGOT-PASSWORD] ✓ Processus termin\xe9 avec succ\xe8s pour ${m.email}`):console.warn(`[FORGOT-PASSWORD] ⚠ Processus termin\xe9 mais email NON envoy\xe9 pour ${m.email}`),n.NextResponse.json({message:"Si un compte existe avec cette adresse email, vous recevrez un lien de r\xe9initialisation."})}catch(e){return console.error("Erreur lors de la demande de r\xe9initialisation:",e),console.error("Stack trace:",e?.stack),n.NextResponse.json({error:"Une erreur est survenue"},{status:500})}}let x=new t.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/auth/forgot-password/route",pathname:"/api/auth/forgot-password",filename:"route",bundlePath:"app/api/auth/forgot-password/route"},resolvedPagePath:"C:\\Users\\dj-ke.DESKTOP-1UI8AT5\\Documents\\weqeep-test\\app\\api\\auth\\forgot-password\\route.ts",nextConfigOutput:"",userland:s}),{requestAsyncStorage:S,staticGenerationAsyncStorage:v,serverHooks:O}=x,g="/api/auth/forgot-password/route";function P(){return(0,a.patchFetch)({serverHooks:O,staticGenerationAsyncStorage:v})}}};var r=require("../../../../webpack-runtime.js");r.C(e);var o=e=>r(r.s=e),s=r.X(0,[4736,8592],()=>o(53780));module.exports=s})();