"use strict";(()=>{var e={};e.id=7212,e.ids=[7212],e.modules={72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},27790:e=>{e.exports=require("assert")},61212:e=>{e.exports=require("async_hooks")},78893:e=>{e.exports=require("buffer")},61282:e=>{e.exports=require("child_process")},84770:e=>{e.exports=require("crypto")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},20629:e=>{e.exports=require("fs/promises")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},86624:e=>{e.exports=require("querystring")},74175:e=>{e.exports=require("tty")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},36855:(e,t,s)=>{s.r(t),s.d(t,{originalPathname:()=>v,patchFetch:()=>m,requestAsyncStorage:()=>g,routeModule:()=>f,serverHooks:()=>E,staticGenerationAsyncStorage:()=>$});var r={};s.r(r),s.d(r,{POST:()=>d});var i=s(49303),o=s(88716),a=s(60670),n=s(87070),c=s(75571),u=s(90455),l=s(61282),p=s(21764),h=s(20629),x=s(55315);async function d(e){try{if(!await (0,c.getServerSession)(u.L))return n.NextResponse.json({error:"Non autoris\xe9"},{status:401});let{configContent:t,serverType:s,domain:r}=await e.json();if(!t||!s||!r)return n.NextResponse.json({error:"Configuration incompl\xe8te"},{status:400});let i="apache"===s?`/etc/apache2/sites-available/${r}.conf`:`/etc/nginx/sites-available/${r}.conf`,o=x.join(process.cwd(),"vhost-configs");await h.mkdir(o,{recursive:!0});let a=x.join(o,`${r}.conf`);await h.writeFile(a,t,"utf-8");let l="apache"===s?`#!/bin/bash
# Script d'installation Virtual Host Apache pour ${r}
# Ex\xe9cuter avec: sudo bash install-${r}.sh

set -e

CONFIG_FILE="${a}"
TARGET_FILE="/etc/apache2/sites-available/${r}.conf"

echo "Installation de la configuration Virtual Host pour ${r}..."

# Copier le fichier de configuration
sudo cp "$CONFIG_FILE" "$TARGET_FILE"

# Activer le site
sudo a2ensite ${r}.conf

# Tester la configuration
echo "Test de la configuration Apache..."
if sudo apache2ctl configtest; then
    echo "Configuration valide!"
    echo "Rechargement d'Apache..."
    sudo systemctl reload apache2
    echo "Virtual Host ${r} install\xe9 avec succ\xe8s!"
    echo "Acc\xe9dez \xe0: http://${r}"
else
    echo "ERREUR: La configuration Apache est invalide!"
    exit 1
fi
`:`#!/bin/bash
# Script d'installation Virtual Host Nginx pour ${r}
# Ex\xe9cuter avec: sudo bash install-${r}.sh

set -e

CONFIG_FILE="${a}"
TARGET_FILE="/etc/nginx/sites-available/${r}.conf"
ENABLED_FILE="/etc/nginx/sites-enabled/${r}.conf"

echo "Installation de la configuration Virtual Host pour ${r}..."

# Copier le fichier de configuration
sudo cp "$CONFIG_FILE" "$TARGET_FILE"

# Cr\xe9er le lien symbolique
if [ -L "$ENABLED_FILE" ]; then
    sudo rm "$ENABLED_FILE"
fi
sudo ln -s "$TARGET_FILE" "$ENABLED_FILE"

# Tester la configuration
echo "Test de la configuration Nginx..."
if sudo nginx -t; then
    echo "Configuration valide!"
    echo "Rechargement de Nginx..."
    sudo systemctl reload nginx
    echo "Virtual Host ${r} install\xe9 avec succ\xe8s!"
    echo "Acc\xe9dez \xe0: http://${r}"
else
    echo "ERREUR: La configuration Nginx est invalide!"
    exit 1
fi
`,p=x.join(o,`install-${r}.sh`);return await h.writeFile(p,l,"utf-8"),await h.chmod(p,"755"),n.NextResponse.json({success:!0,message:"Configuration g\xe9n\xe9r\xe9e. Utilisez le script d'installation fourni.",configPath:a,scriptPath:p,instructions:"apache"===s?[`1. Copiez le fichier: sudo cp ${a} ${i}`,`2. Activez le site: sudo a2ensite ${r}.conf`,"3. Testez: sudo apache2ctl configtest","4. Rechargez: sudo systemctl reload apache2",`Ou ex\xe9cutez: sudo bash ${p}`]:[`1. Copiez le fichier: sudo cp ${a} ${i}`,`2. Cr\xe9ez le lien: sudo ln -s ${i} /etc/nginx/sites-enabled/${r}.conf`,"3. Testez: sudo nginx -t","4. Rechargez: sudo systemctl reload nginx",`Ou ex\xe9cutez: sudo bash ${p}`]})}catch(e){return console.error("Erreur:",e),n.NextResponse.json({error:"Une erreur est survenue: "+e.message},{status:500})}}(0,p.promisify)(l.exec);let f=new i.AppRouteRouteModule({definition:{kind:o.x.APP_ROUTE,page:"/api/vhost/apply/route",pathname:"/api/vhost/apply",filename:"route",bundlePath:"app/api/vhost/apply/route"},resolvedPagePath:"C:\\Users\\dj-ke.DESKTOP-1UI8AT5\\Documents\\weqeep-test\\app\\api\\vhost\\apply\\route.ts",nextConfigOutput:"",userland:r}),{requestAsyncStorage:g,staticGenerationAsyncStorage:$,serverHooks:E}=f,v="/api/vhost/apply/route";function m(){return(0,a.patchFetch)({serverHooks:E,staticGenerationAsyncStorage:$})}}};var t=require("../../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),r=t.X(0,[4736,8592],()=>s(36855));module.exports=r})();